read -p "Enter Your Name : " name
read -p "Enter Your Degree Program : " prog
read -p "Enter Your batch : " batch
read -p "Enter Your Course Title :" cour

for i in {1..10}
do 
echo "*"
done

echo "Your Name : $name"
echo "Your Degree Program : $prog"
echo "Your batch : $batch"
echo "Your Course : $cour"

