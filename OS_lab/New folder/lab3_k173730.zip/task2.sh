read -p "Enter Num : " num
zero=0

if [[ $num -gt $zero ]];then
echo "$num is positive"
else
echo "$num is negative"
fi

