m="Welcome To the World of Shell Scripting"
for i in {1..10}
	do 
		echo $m
	done

